import * as React from 'react';
import { FocusZone, FocusZoneDirection } from 'office-ui-fabric-react/lib/FocusZone';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { Image, ImageFit } from 'office-ui-fabric-react/lib/Image';
import { List } from 'office-ui-fabric-react/lib/List';
import { ITheme, mergeStyleSets, getTheme, getFocusStyle } from 'office-ui-fabric-react/lib/Styling';
import { useConst } from '@uifabric/react-hooks';
import{IBike} from '../IBikeCatelogState';

const theme: ITheme = getTheme();
const { palette, semanticColors, fonts } = theme;

const classNames = mergeStyleSets({
  itemCell: [
    getFocusStyle(theme, { inset: -1 }),
    {
      minHeight: 54,
      padding: 10,
      boxSizing: 'border-box',
      borderBottom: `1px solid ${semanticColors.bodyDivider}`,
      display: 'flex',
    },
  ],
  itemImage: {
    flexShrink: 0,
  },
  itemContent: {
    marginLeft: 10,
    overflow: 'hidden',
    flexGrow: 1,
    color:"[theme: themeDark, default: #005a9e]",
  },
  itemName: [
    fonts.xLarge,
    {
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    },
  ],
  itemIndex: {
    fontSize: fonts.small.fontSize,
    color: palette.neutralTertiary,
    marginBottom: 10,
  },
  chevron: {
    alignSelf: 'center',
    marginLeft: 10,
    color:"[theme: themeDark, default: #005a9e]",
    fontSize: fonts.large.fontSize,
    flexShrink: 0,
  },
});

const onRenderCell = (item: IBike, index: number | undefined): JSX.Element => {
  return (
    <div className={classNames.itemCell} data-is-focusable={true}>
      <Image className={classNames.itemImage} src={item.ImageUrl} width={50} height={50} imageFit={ImageFit.contain} />
      <div className={classNames.itemContent}>
        <div className={classNames.itemName}>{item.Title}</div>        
        <div>{item.BikeDescription}</div>
      </div>
    </div>
  );
};

export function BikeList({allBikesItems}){ 
  
  const originalItems = useConst(() => allBikesItems);
  const [BikeItems, setItems] = React.useState(originalItems);

  const resultCountText =  BikeItems.length === originalItems.length ? '' : ` (${BikeItems.length} of ${BikeItems.length} shown)`;

  const onFilterChanged = (_: any, text: string): void => {
    setItems(originalItems.filter(item => item.Title.toLowerCase().indexOf(text.toLowerCase()) >= 0));
  };

  return (
    <FocusZone direction={FocusZoneDirection.vertical}>
      <TextField label={'Filter by Modal Name' + resultCountText} onChange={onFilterChanged} />
      <List items={BikeItems} onRenderCell={onRenderCell} />
    </FocusZone>
  );
}; 