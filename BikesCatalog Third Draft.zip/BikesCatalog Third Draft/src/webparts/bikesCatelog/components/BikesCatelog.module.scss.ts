/* tslint:disable */
require("./BikesCatelog.module.css");
const styles = {
  bikesCatelog: 'bikesCatelog_e6e7d3ae',
  title: 'title_e6e7d3ae'
};

export default styles;
/* tslint:enable */