import * as React from 'react';
import styles from './BikesCatelog.module.scss';
import { IBikesCatelogProps } from './IBikesCatelogProps';
import { IBikeCatelogState ,IBike} from './IBikeCatelogState';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { PivotItem, Pivot } from 'office-ui-fabric-react/lib/Pivot';
import BikeCard from './BikeCardComponent/BikeCard';
import { BikeList } from './BikeListComponent/BikeList';
import {BikeDetailList} from './BikeDetailsComponent/BikeDetails';
import{pnp} from '../_PnPServices/PnPServices';

export default class BikesCatelog extends React.Component<IBikesCatelogProps,IBikeCatelogState> {
  constructor(props:IBikesCatelogProps,state:IBikeCatelogState){
    super(props);
    this.state={
      listItems:[],
      listColumns:["Bike Modal","Brand","Description of Bike","Bike Launch Date","Price($)","Presented By"]
    }
  }

  onListItemChange = items =>{
    this.setState({listItems : items});
  }

  public componentDidMount(): void {
     this.getAllRecords();    
  }

  protected getAllRecords(){
    pnp.getAllItems(this.props.listName,"ID,Title,ImageUrl,Brand,BikeDescription,Price,LaunchDate,Presenter/Title,Presenter/Id,Presenter/EMail","Presenter").then((response:IBike[]) => {
      this.setState({
        listItems:response
      });
      console.log("updating state");
    }).catch(error =>{
      console.log("Error Occured in fetching records");
    });
  }

  public render(): React.ReactElement<IBikesCatelogProps> { 
    return (         
    <div className={ styles.bikesCatelog }>
      <Pivot>

        <PivotItem headerText="Tile View" itemIcon="PictureLibrary">
          <Label className={styles.title}>Tile View</Label>
          {
            this.state.listItems.map((item:IBike,index)=>{
              return <BikeCard BikeItem={item} key={item.ID}></BikeCard>
            })
          }
        </PivotItem>

        <PivotItem headerText="List View" itemIcon="CustomList">
          <Label className={styles.title}>List View</Label>
          <BikeList allBikesItems={this.state.listItems}></BikeList>         
        </PivotItem>

        <PivotItem headerText="Detailed View" itemIcon="PageListFilter">
          <Label className={styles.title}>Detailed View</Label>
          <BikeDetailList ListName = {this.props.listName} ListItems={this.state.listItems} ListColumns={this.state.listColumns} onItemsChange = {this.onListItemChange}></BikeDetailList>         
        </PivotItem>   

      </Pivot>
    </div>   
    );
  }
}