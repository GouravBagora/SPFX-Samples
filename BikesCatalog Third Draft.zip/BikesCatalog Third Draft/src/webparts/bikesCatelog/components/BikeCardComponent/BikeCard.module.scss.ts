/* tslint:disable */
require("./BikeCard.module.css");
const styles = {
  bike: 'bike_ff3f04ee',
  card: 'card_ff3f04ee'
};

export default styles;
/* tslint:enable */