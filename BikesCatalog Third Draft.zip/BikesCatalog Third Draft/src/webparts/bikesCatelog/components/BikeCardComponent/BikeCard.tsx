import * as React from 'react';
import {
  DocumentCard,
  DocumentCardActivity,
  DocumentCardTitle,
  DocumentCardDetails,
  DocumentCardImage,
  IDocumentCardStyles,
  IDocumentCardActivityPerson,
  DocumentCardStatus
} from 'office-ui-fabric-react/lib/DocumentCard';
import { ImageFit } from 'office-ui-fabric-react/lib/Image';

export default function BikeCard({ BikeItem }) {
  const cardStyles: IDocumentCardStyles = {
    root: { display: 'inline-block', marginRight: 20, marginBottom: 20, width: 350 },
  };

  let activity = null;  

  if (typeof BikeItem.Presenter != "undefined" && BikeItem.Presenter != null) {
    const people: IDocumentCardActivityPerson = {
        name: BikeItem.Presenter.Title, profileImageSrc: "/mt/v3/people/profileimage?size=s&amp;userId=" + BikeItem.Presenter.EMail, initials: null
    };

    activity = <DocumentCardActivity activity={"Launch Date: " + new Intl.DateTimeFormat("en-GB", {
      year: "numeric",
      month: "long",
      day: "2-digit"
    }).format(new Date(BikeItem.LaunchDate))} people={[people]} />
  }
  else {
    activity = <DocumentCardStatus status = {"Launch Date: " + new Intl.DateTimeFormat("en-GB", {
      year: "numeric",
      month: "long",
      day: "2-digit"
    }).format(new Date(BikeItem.LaunchDate))}/>
  } 

  return (
    <>

      <DocumentCard styles={cardStyles}>

        <DocumentCardImage height={150} imageFit={ImageFit.cover} imageSrc={BikeItem.ImageUrl} />

        <DocumentCardDetails>
          <DocumentCardTitle title={BikeItem.Title} />
          <DocumentCardStatus status={BikeItem.Brand} />
          <DocumentCardTitle title={BikeItem.BikeDescription} showAsSecondaryTitle shouldTruncate />
        </DocumentCardDetails>

        {activity}

      </DocumentCard>

    </>
  );
};