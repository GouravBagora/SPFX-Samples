import * as React from 'react';
import {
  MessageBar,
  MessageBarType,
} from 'office-ui-fabric-react';

interface IExampleProps {
  ErrorMsg?: string;
}

export const ErrorMessage = (p: IExampleProps) => (
    <MessageBar
      messageBarType={MessageBarType.error}
      isMultiline={false}
      dismissButtonAriaLabel="Close"
    >
      {p.ErrorMsg}
    </MessageBar>
);