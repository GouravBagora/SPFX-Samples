/// <reference types="react" />
export declare function BikeList({ allBikesItems }: {
    allBikesItems: any;
}): JSX.Element;
//# sourceMappingURL=BikeList.d.ts.map