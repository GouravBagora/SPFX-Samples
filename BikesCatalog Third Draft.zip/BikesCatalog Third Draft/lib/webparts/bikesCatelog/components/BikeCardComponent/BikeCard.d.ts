/// <reference types="react" />
export default function BikeCard({ BikeItem }: {
    BikeItem: any;
}): JSX.Element;
//# sourceMappingURL=BikeCard.d.ts.map