declare const styles: {
    bike: string;
    card: string;
};
export default styles;
//# sourceMappingURL=BikeCard.module.scss.d.ts.map