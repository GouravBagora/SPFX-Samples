import * as React from 'react';
import { IColumn } from 'office-ui-fabric-react/lib/DetailsList';
import { IBike } from '../IBikeCatelogState';
export interface IBikeDetailsListProps {
    ListItems: IBike[];
    ListColumns: string[];
    ListName: string;
    onItemsChange: Function;
}
export interface IBikeDetailsListState {
    ListItems: IBike[];
    ListColumns: IColumn[];
    selectionDetails: string;
    openPanel: boolean;
    panelType: string;
    BrandValue: string;
}
export declare class BikeDetailList extends React.Component<IBikeDetailsListProps, IBikeDetailsListState> {
    private _selection;
    constructor(props: IBikeDetailsListProps, state: IBikeDetailsListState);
    private formObj;
    private onBrandChange;
    private onChangeLaunchDate;
    private onFormChange;
    private onPresenterChange;
    private _renderItemColumn;
    private _getSelectionDetails;
    private dismissPanel;
    private saveItem;
    private updateItem;
    private onRenderFooterContent;
    private onNewClick;
    private onViewClick;
    private onUpdateClick;
    private onDeleteClick;
    private updateComponents;
    private commandBarActions;
    render(): JSX.Element;
}
//# sourceMappingURL=BikeDetails.d.ts.map