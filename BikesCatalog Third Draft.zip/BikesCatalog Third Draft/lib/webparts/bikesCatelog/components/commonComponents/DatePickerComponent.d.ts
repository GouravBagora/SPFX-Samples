/// <reference types="react" />
export declare const DatePickerComponent: ({ onDateSelect, dLabel, dVal, dIsReq }: {
    onDateSelect: any;
    dLabel: any;
    dVal: any;
    dIsReq: any;
}) => JSX.Element;
//# sourceMappingURL=DatePickerComponent.d.ts.map