/// <reference types="react" />
interface IExampleProps {
    ErrorMsg?: string;
}
export declare const ErrorMessage: (p: IExampleProps) => JSX.Element;
export {};
//# sourceMappingURL=ErrorMessage.d.ts.map