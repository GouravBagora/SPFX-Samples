/// <reference types="react" />
export declare function DatePickerComponent({ ref, dLabel, dVal, dIsReq }: {
    ref: any;
    dLabel: any;
    dVal: any;
    dIsReq: any;
}): JSX.Element;
//# sourceMappingURL=DatePicker.d.ts.map