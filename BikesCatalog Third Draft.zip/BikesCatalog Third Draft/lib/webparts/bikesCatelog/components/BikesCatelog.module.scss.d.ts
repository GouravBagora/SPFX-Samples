declare const styles: {
    bikesCatelog: string;
    title: string;
};
export default styles;
//# sourceMappingURL=BikesCatelog.module.scss.d.ts.map