declare const styles: {
    areaDetails: string;
    card: string;
    container: string;
};
export default styles;
//# sourceMappingURL=AreaDetails.module.scss.d.ts.map