import * as React from 'react';
import { IAreaDetailsProps } from './IAreaDetailsProps';
import { IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
interface IAreaDetailsState {
    allAreasDetails: any[];
    countryDDOptions: IDropdownOption[];
    stateDDOptions: IDropdownOption[];
    cityDDOptions: IDropdownOption[];
    selectedCountry: string;
    selectedState: string;
    selectedCity: string;
    isDisableStateDD: boolean;
    isDisableCityDD: boolean;
}
export default class AreaDetails extends React.Component<IAreaDetailsProps, IAreaDetailsState> {
    constructor(props: IAreaDetailsProps, state: IAreaDetailsState);
    componentDidMount(): void;
    private getAllAreas;
    onCountryDDChange: (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => void;
    onStateDDChange: (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => void;
    onCityDDChange: (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => void;
    private getDDOptions;
    render(): React.ReactElement<IAreaDetailsProps>;
}
export {};
//# sourceMappingURL=AreaDetails.d.ts.map