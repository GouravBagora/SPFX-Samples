declare function getAllItems(listName: string, selectString: string, expandString: string, top: number, orderBy: string, isOrderAsc: boolean): Promise<any[]>;
export declare const pnpService: {
    getAllItems: typeof getAllItems;
};
export {};
//# sourceMappingURL=services.d.ts.map