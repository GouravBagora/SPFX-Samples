import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import AreaDetails from './components/AreaDetails';
import { IAreaDetailsProps } from './components/IAreaDetailsProps';
import { sp } from '@pnp/sp';



export interface IAreaDetailsWebPartProps {
  colorForDensePopulatedArea: string;
  colorForModeratePopulatedArea: string;
  colorForLowPopulatedArea: string;
}

export default class AreaDetailsWebPart extends BaseClientSideWebPart<IAreaDetailsWebPartProps> {

  public onInit(): Promise<void> {
    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public render(): void {
    const element: React.ReactElement<IAreaDetailsProps> = React.createElement(
      AreaDetails,
      {
        densePopulationAreaColor: this.properties.colorForDensePopulatedArea,
        moderatePopulationAreaColor: this.properties.colorForModeratePopulatedArea,
        lowPopulationAreaColor: this.properties.colorForLowPopulatedArea,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: "Get Area details for selected City"
          },
          groups: [
            {
              groupName: "Customize Area(s) Card",
              groupFields: [
                PropertyPaneTextField('colorForDensePopulatedArea', {
                  label: "Provide Color Name for Highly Populated Area",
                  value: "Red",
                }),
                PropertyPaneTextField('colorForModeratePopulatedArea', {
                  label: "Provide Color Name for Moderately Populated Area",
                  value: "Orange",
                }),
                PropertyPaneTextField('colorForLowPopulatedArea', {
                  label: "Provide Color Name for low Populated Area",
                  value: "Green",
                })
              ],
            }
          ]
        }
      ]
    };
  }
}