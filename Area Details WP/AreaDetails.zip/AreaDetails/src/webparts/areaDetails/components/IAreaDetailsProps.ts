export interface IAreaDetailsProps {
  densePopulationAreaColor: string;
  moderatePopulationAreaColor: string;
  lowPopulationAreaColor: string;
}
