/* tslint:disable */
require("./AreaDetails.module.css");
const styles = {
  areaDetails: 'areaDetails_da96cb16',
  card: 'card_da96cb16',
  container: 'container_da96cb16'
};

export default styles;
/* tslint:enable */