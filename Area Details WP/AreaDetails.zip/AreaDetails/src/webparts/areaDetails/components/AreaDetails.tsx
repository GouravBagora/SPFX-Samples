import * as React from 'react';
import styles from './AreaDetails.module.scss';
import { IAreaDetailsProps } from './IAreaDetailsProps';
import { pnpService } from '../services';
import { Dropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';

interface IAreaDetailsState {
  allAreasDetails: any[];
  countryDDOptions: IDropdownOption[];
  stateDDOptions: IDropdownOption[];
  cityDDOptions: IDropdownOption[];
  selectedCountry: string;
  selectedState: string;
  selectedCity: string;
  isDisableStateDD: boolean;
  isDisableCityDD: boolean;
}

export default class AreaDetails extends React.Component<IAreaDetailsProps, IAreaDetailsState> {
  public constructor(props: IAreaDetailsProps, state: IAreaDetailsState) {
    super(props);
    this.state = {
      allAreasDetails: [],
      countryDDOptions: [],
      stateDDOptions: [],
      cityDDOptions: [],
      selectedCountry: "",
      selectedState: "",
      selectedCity: "",
      isDisableCityDD: true,
      isDisableStateDD: true
    };
  }

  public componentDidMount() {
    this.getAllAreas().then((allAreasDetails) => {
      console.log(allAreasDetails);

      this.setState({
        allAreasDetails: allAreasDetails
      });

      if (allAreasDetails.length > 0) {
        let countryDDOptions = this.getDDOptions(this.state.allAreasDetails, "Country", "", "");
        this.setState({
          countryDDOptions: countryDDOptions
        });
      }
    });
  }

  private getAllAreas(): Promise<any[]> {
    return pnpService.getAllItems("Area", "Title,Country,State,City,PinCode,Population", "", 5000, "Title", true).then((resp) => {
      console.log("Success : getAllAreas().getAllItems()");
      return Promise.resolve(resp);
    }).catch((error) => {
      console.log("Exception : getAllAreas().getAllItems()");
      console.log(error);
      return Promise.resolve([]);
    });
  }

  public onCountryDDChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
    let selectedCountry = option.text;
    let stateDDOptions = this.getDDOptions(this.state.allAreasDetails, "State", selectedCountry, "");

    this.setState(prevState => ({
      ...prevState,
      selectedCountry: selectedCountry,
      stateDDOptions: stateDDOptions,
      cityDDOptions: [],
      isDisableStateDD: false,
      isDisableCityDD: true,
      selectedCity: ""
    }));
  }

  public onStateDDChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
    let selectedState = option.text;
    let cityDDOptions = this.getDDOptions(this.state.allAreasDetails, "City", this.state.selectedCountry, selectedState);
    this.setState(prevState => ({
      ...prevState,
      selectedState: selectedState,
      cityDDOptions: cityDDOptions,
      isDisableCityDD: false,
      selectedCity: ""
    }));
  }

  public onCityDDChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
    let selectedCity = option.text;
    this.setState(prevState => ({
      ...prevState,
      selectedCity: selectedCity
    }));
  }

  private getDDOptions = (array: any, flag: string, selectedCountry: string, selectedState: string): IDropdownOption[] => {
    let options = [];
    let option = {};
    array.filter((item) => {
      if (flag == "Country") {
        option = { key: item.Country, text: item.Country };
        options.push(option);
      }
      else if (flag == "State") {
        if (item.Country == selectedCountry) {
          option = { key: item.State, text: item.State };
          options.push(option);
        }
      }
      else {
        if (item.Country == selectedCountry && item.State == selectedState) {
          option = { key: item.City, text: item.City };
          options.push(option);
        }
      }
    });

    let uniqueOptions = options.reduce((acc, current) => {
      const x = acc.find(item => item.key === current.key);
      if (!x) {
        return acc.concat([current]);
      } else {
        return acc;
      }
    }, []);
    return uniqueOptions;
  }

  public render(): React.ReactElement<IAreaDetailsProps> {
    let displayCardComponent;

    if (this.state.selectedCity != "") {
      displayCardComponent = this.state.allAreasDetails.map(item => {
        if (item.City == this.state.selectedCity) {
          let bgColor = (item.Population > 10000) ? this.props.densePopulationAreaColor :
            (item.Population <= 10000 && item.Population > 5000) ? this.props.moderatePopulationAreaColor :
              this.props.lowPopulationAreaColor;
          return <div className={styles.card} style={{ backgroundColor: bgColor }}>
            <div className={styles.container}>
              <h2>{item.Title}</h2>
              <h4><b>Pin Code</b>: {item.PinCode}</h4>
              <p>Population: {item.Population}</p>
            </div>
          </div>;
        }
      });
    }
    else {
      displayCardComponent = <div></div>
    }

    return (
      <div className={styles.areaDetails}>
        <div>
          <Dropdown
            label="Country"
            placeholder="Select a Country"
            options={this.state.countryDDOptions}
            onChange={this.onCountryDDChange}
          />

          <Dropdown
            label="State"
            placeholder="Select a State"
            selectedKey={this.state.selectedState}
            options={this.state.stateDDOptions}
            disabled={this.state.isDisableStateDD}
            onChange={this.onStateDDChange}
          />

          <Dropdown
            label="City"
            placeholder="Select a City"
            selectedKey={this.state.selectedCity}
            options={this.state.cityDDOptions}
            disabled={this.state.isDisableCityDD}
            onChange={this.onCityDDChange}
          />
        </div>
        <div>
          {displayCardComponent}
        </div>
      </div>
    );
  }
}