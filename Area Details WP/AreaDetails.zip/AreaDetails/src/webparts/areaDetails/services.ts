import { sp } from '@pnp/sp/presets/all';

function getAllItems(listName: string, selectString: string, expandString: string, top: number, orderBy: string, isOrderAsc: boolean): Promise<any[]> {
    return sp.web.lists.getByTitle(listName).items.select(selectString).expand(expandString).top(top).orderBy(orderBy, isOrderAsc).get().then(
        (response) => {
            console.log("Success: getAllItems() for list - " + listName);
            return response;
        }
    ).catch(error => {
        console.log("Exception: getAllItems() for list - " + listName);
        console.log(error);
        throw new Error(error);
    });
}

export const pnpService = {
    getAllItems
};