declare interface IAreaDetailsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AreaDetailsWebPartStrings' {
  const strings: IAreaDetailsWebPartStrings;
  export = strings;
}
