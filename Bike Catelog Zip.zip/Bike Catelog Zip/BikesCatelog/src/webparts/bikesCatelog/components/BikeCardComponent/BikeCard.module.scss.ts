/* tslint:disable */
require("./BikeCard.module.css");
const styles = {
  bike: 'bike_8da1e674',
  card: 'card_8da1e674',
  container: 'container_8da1e674'
};

export default styles;
/* tslint:enable */