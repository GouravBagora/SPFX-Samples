/* tslint:disable */
require("./Custom.module.css");
const styles = {
  bike: 'bike_5918c7e9',
  card: 'card_5918c7e9',
  container: 'container_5918c7e9'
};

export default styles;
/* tslint:enable */