/* tslint:disable */
require("./BikeList.module.css");
const styles = {

};

export default styles;
/* tslint:enable */