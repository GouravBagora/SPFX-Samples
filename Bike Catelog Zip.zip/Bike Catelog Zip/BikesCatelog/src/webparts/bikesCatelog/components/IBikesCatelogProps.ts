export interface IBikesCatelogProps {
  description: string;
  listName: string;
}
