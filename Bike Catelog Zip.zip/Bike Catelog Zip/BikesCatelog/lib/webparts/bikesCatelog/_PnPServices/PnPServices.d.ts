import { IBike } from '../components/IBikeCatelogState';
declare function getAllItems(listName: string, selectString: string, expandString: string): Promise<IBike[]>;
declare function getItemById(listName: string, selectString: string, expandString: string): Promise<IBike[]>;
declare function addItem(listName: string, itemObj: object): Promise<IBike[]>;
declare function deleteItem(listName: string, itemID: number): Promise<IBike[]>;
declare function updateItemById(listName: string, itemID: number, itemObj: object): Promise<IBike[]>;
export declare const pnp: {
    getAllItems: typeof getAllItems;
    getItemById: typeof getItemById;
    addItem: typeof addItem;
    deleteItem: typeof deleteItem;
    updateItemById: typeof updateItemById;
};
export {};
//# sourceMappingURL=PnPServices.d.ts.map