export interface IBikesCatelogProps {
    description: string;
    listName: string;
}
//# sourceMappingURL=IBikesCatelogProps.d.ts.map