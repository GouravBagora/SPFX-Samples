import * as React from 'react';
import { IBikesCatelogProps } from './IBikesCatelogProps';
import { IBikeCatelogState } from './IBikeCatelogState';
export default class BikesCatelog extends React.Component<IBikesCatelogProps, IBikeCatelogState> {
    constructor(props: IBikesCatelogProps, state: IBikeCatelogState);
    onListItemChange: (items: any) => void;
    componentDidMount(): void;
    protected getAllRecords(): void;
    render(): React.ReactElement<IBikesCatelogProps>;
}
//# sourceMappingURL=BikesCatelog.d.ts.map