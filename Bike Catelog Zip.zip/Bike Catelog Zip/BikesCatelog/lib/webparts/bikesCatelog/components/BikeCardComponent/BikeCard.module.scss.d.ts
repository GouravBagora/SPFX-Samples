declare const styles: {
    bike: string;
    card: string;
    container: string;
};
export default styles;
//# sourceMappingURL=BikeCard.module.scss.d.ts.map