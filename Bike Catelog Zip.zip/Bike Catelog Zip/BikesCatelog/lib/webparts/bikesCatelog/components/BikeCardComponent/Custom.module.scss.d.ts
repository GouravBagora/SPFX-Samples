declare const styles: {
    bike: string;
    card: string;
    container: string;
};
export default styles;
//# sourceMappingURL=Custom.module.scss.d.ts.map