/// <reference types="react" />
export default function BikeCard(Item: any): JSX.Element;
//# sourceMappingURL=BikeCard.d.ts.map