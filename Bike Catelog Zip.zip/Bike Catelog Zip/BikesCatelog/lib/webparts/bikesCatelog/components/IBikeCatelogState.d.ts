export interface Users {
    Id: number;
    Title: string;
    EMail: string;
}
export interface IBike {
    ID: number;
    Title: string;
    ImageUrl: string;
    Brand: string;
    BikeDescription: string;
    Price: number;
    LaunchDate: string;
    Presenter: Users;
}
export interface IBikeCatelogState {
    listItems: IBike[];
    listColumns: string[];
}
//# sourceMappingURL=IBikeCatelogState.d.ts.map