/// <reference types="react" />
export declare function BikeList(props: any): JSX.Element;
//# sourceMappingURL=BikeList.d.ts.map