declare const styles: {};
export default styles;
//# sourceMappingURL=BikeList.module.scss.d.ts.map