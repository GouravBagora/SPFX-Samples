import * as React from 'react';
export declare const PeoplePicker: React.FunctionComponent;
//# sourceMappingURL=PeoplePicker.d.ts.map