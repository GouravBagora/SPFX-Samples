import * as React from 'react';
export declare const NewBike: React.FunctionComponent<{
    openSidePanel: boolean;
}>;
//# sourceMappingURL=NewBike.d.ts.map