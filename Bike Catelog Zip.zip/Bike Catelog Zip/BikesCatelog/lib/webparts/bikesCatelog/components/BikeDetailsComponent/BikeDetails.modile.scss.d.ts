declare const styles: {};
export default styles;
//# sourceMappingURL=BikeDetails.modile.scss.d.ts.map