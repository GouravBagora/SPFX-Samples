import * as React from 'react';
import { IColumn } from 'office-ui-fabric-react/lib/DetailsList';
import { IBike } from '../IBikeCatelogState';
export interface IBikeDetailsListProps {
    ListItems: IBike[];
    ListColumns: string[];
    ListName: string;
    onItemsChange: Function;
}
export interface IBikeDetailsListState {
    ListItems: IBike[];
    ListColumns: IColumn[];
    selectionDetails: string;
    openPanel: boolean;
    panelType: string;
    BrandValue: string;
}
export declare class BikeDetailList extends React.Component<IBikeDetailsListProps, IBikeDetailsListState> {
    private _selection;
    private _columns;
    private _items;
    formObj: IBike;
    private onBrandChange;
    private onFormChange;
    constructor(props: IBikeDetailsListProps, state: IBikeDetailsListState);
    render(): JSX.Element;
    private _renderItemColumn;
    private _getSelectionDetails;
    private dismissPanel;
    private saveItem;
    private updateItem;
    private onRenderFooterContent;
    private onNewClick;
    private onViewClick;
    private onUpdateClick;
    private onDeleteClick;
}
//# sourceMappingURL=BikeDetails.d.ts.map