/// <reference types="react" />
export declare function PeoplePicker({ onPresenterSelect, currentPresenter }: {
    onPresenterSelect: any;
    currentPresenter: any;
}): JSX.Element;
//# sourceMappingURL=PeoplePicker.d.ts.map