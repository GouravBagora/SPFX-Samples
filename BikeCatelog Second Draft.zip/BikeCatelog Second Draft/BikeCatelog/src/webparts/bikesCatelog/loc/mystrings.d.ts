declare interface IBikesCatelogWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BikesCatelogWebPartStrings' {
  const strings: IBikesCatelogWebPartStrings;
  export = strings;
}
