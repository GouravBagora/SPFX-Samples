import * as React from 'react';
import {
    DocumentCard,
    DocumentCardActivity,
    DocumentCardTitle,
    DocumentCardDetails,
    DocumentCardImage,
    IDocumentCardStyles,
    IDocumentCardActivityPerson,
    DocumentCardStatus
  } from 'office-ui-fabric-react/lib/DocumentCard';
  import { ImageFit } from 'office-ui-fabric-react/lib/Image';

  export default function BikeCard(Item:any){    
      const cardStyles: IDocumentCardStyles = {
        root: { display: 'inline-block', marginRight: 20, marginBottom: 20, width: 350 },
      };  
      const people: IDocumentCardActivityPerson[]=[
        {name: Item.BikeItem.Presenter.Title,  profileImageSrc: '', initials: Item.BikeItem.Presenter.Title.split(' ')[0].slice(0,1) + Item.BikeItem.Presenter.Title.split(' ')[1].slice(0,1)}
      ];
      return (
        <>
          <DocumentCard            
            styles={cardStyles}
          >
            <DocumentCardImage height={150} imageFit={ImageFit.cover} imageSrc={Item.BikeItem.ImageUrl} />
            <DocumentCardDetails>
              <DocumentCardTitle title={Item.BikeItem.Title} />
              <DocumentCardStatus  status={Item.BikeItem.Brand} />
              <DocumentCardTitle title={Item.BikeItem.BikeDescription} showAsSecondaryTitle shouldTruncate />
            </DocumentCardDetails>
            <DocumentCardActivity activity={"Launch Date: "+ new Intl.DateTimeFormat("en-GB",{
              year: "numeric",
              month: "long",
              day: "2-digit"
            }).format(new Date(Item.BikeItem.LaunchDate))} people={[people[0]]} />
          </DocumentCard>
        </>
      );
};