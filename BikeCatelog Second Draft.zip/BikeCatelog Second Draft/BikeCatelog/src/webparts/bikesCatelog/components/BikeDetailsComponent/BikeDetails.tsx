import * as React from 'react';
import { CommandBar, ICommandBarItemProps } from 'office-ui-fabric-react/lib/CommandBar';
import { Announced } from 'office-ui-fabric-react/lib/Announced';
import { DetailsList, DetailsListLayoutMode, Selection, IColumn } from 'office-ui-fabric-react/lib/DetailsList';
import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { Fabric } from 'office-ui-fabric-react/lib/Fabric';
import { mergeStyles, noWrap } from 'office-ui-fabric-react/lib/Styling';
import { DefaultButton, PrimaryButton, Button } from 'office-ui-fabric-react/lib/Button';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { Image, IImageProps, ImageFit } from 'office-ui-fabric-react/lib/Image';
import { Text } from 'office-ui-fabric-react/lib/Text';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { Separator } from 'office-ui-fabric-react/lib/Separator';
import { Label, ILabelStyles } from 'office-ui-fabric-react/lib/Label';
import { Dropdown, TextField, ActivityItem, mergeStyleSets, IActivityItemProps, Icon, IDropdownOption, IDropdownStyles, IPersonaSharedProps } from 'office-ui-fabric-react';
import { DatePicker, DayOfWeek, IDatePickerStrings } from 'office-ui-fabric-react/lib/DatePicker';
import { pnp } from '../../_PnPServices/PnPServices';
import { PeoplePicker } from '../commonComponents/PeoplePicker';
//import styles from './BikeDetails.modile.scss';
import { IBike } from '../IBikeCatelogState';

const buttonStyles = { root: { marginRight: 8 } };

const exampleChildClass = mergeStyles({
    display: 'block',
    marginBottom: '10px',
    marginTop: '10px',
});

const textAreaClass = mergeStyles({
    width: '100%',
    lineHeight: '1.5em',
    height: '3em',
    overflow: 'hidden',
    whiteSpace: 'noWrap',
    textOverflow: 'ellipsis',
});

const classNames = mergeStyleSets({
    exampleRoot: {
        marginTop: '20px',
    },
    nameText: {
        fontWeight: 'bold',
        color: "[theme: themeDark, default: #005a9e]"
    },

});

const tokens = {
    sectionStack: {
        childrenGap: 10,
    },
    headingStack: {
        childrenGap: 10,
    },
};

const DayPickerStrings: IDatePickerStrings = {
    months: [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
    ],

    shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

    days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

    shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],

    goToToday: 'Go to today',
    prevMonthAriaLabel: 'Go to previous month',
    nextMonthAriaLabel: 'Go to next month',
    prevYearAriaLabel: 'Go to previous year',
    nextYearAriaLabel: 'Go to next year',
    closeButtonAriaLabel: 'Close date picker',

    isRequiredErrorMessage: 'Start date is required.',

    invalidInputErrorMessage: 'Invalid date format.',
};

export interface IBikeDetailsListProps {
    ListItems: IBike[],
    ListColumns: string[],
    ListName: string,
    onItemsChange: Function
};

export interface IBikeDetailsListState {
    ListItems: IBike[];
    ListColumns: IColumn[];
    selectionDetails: string;
    openPanel: boolean;
    panelType: string;
    BrandValue: string;
};

export class BikeDetailList extends React.Component<IBikeDetailsListProps, IBikeDetailsListState> {
    private _selection: Selection;
    private _columns: IColumn[];
    private _items: ICommandBarItemProps[] = [
        {
            key: 'newItem',
            text: 'New',
            iconProps: { iconName: 'Add' },
            split: true,
            ariaLabel: 'New',
            onClick: () => this.onNewClick(),
        },
        {
            key: 'view',
            text: 'View',
            iconProps: { iconName: 'View' },
            ariaLabel: 'View',
            split: true,
            disabled: true,
            onClick: () => this.onViewClick(),
        },
        {
            key: 'update',
            text: 'Update',
            ariaLabel: 'Update',
            split: true,
            disabled: true,
            onClick: () => this.onUpdateClick(),
        },
        {
            key: 'delete',
            text: 'Delete',
            ariaLabel: 'Delete',
            iconProps: { iconName: 'Delete' },
            iconOnly: true,
            disabled: true,
            onClick: () => this.onDeleteClick(),
        },
    ];

    public formObj: IBike = {
        Title: "",
        Price: 0,
        Brand: "",
        ImageUrl: "",
        BikeDescription: "",
        ID: 0,
        LaunchDate: new Date().toString(),
        Presenter: null
    };

    private onBrandChange = (e: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
        this.formObj.Brand = item.text;
        this.setState({
            BrandValue: item.text
        });
    };

    private onChangeLaunchDate = (date: Date | null | undefined): void => {
        this.formObj.LaunchDate = date.toDateString();
    };

    private onFormChange = (e: any): void => {
        const target = e.target;
        switch (target.id) {
            case "txtModal":
                this.formObj.Title = target.value;
                break;
            case "txtImageUrl":
                this.formObj.ImageUrl = target.value;
                break;
            case "txtBrand":
                this.formObj.Brand = target.value;
                break;
            case "txtBikeDescription":
                this.formObj.BikeDescription = target.value;
                break;
            case "txtPrice":
                this.formObj.Price = target.value;
                break;
        }
    };

    private onPresenterChange = (selectedUser) => {
        this.formObj.Presenter = selectedUser;
    };

    constructor(props: IBikeDetailsListProps, state: IBikeDetailsListState) {
        super(props);

        this._selection = new Selection({
            onSelectionChanged: () => this.setState({ selectionDetails: this._getSelectionDetails() }),
        });

        let columnKey = "";
        let columnField = "";
        this._columns = this.props.ListColumns.map((column) => {
            switch (column) {
                case "Bike Modal":
                    columnKey = "Title";
                    columnField = "Title";
                    break;

                case "Brand":
                    columnKey = "Brand";
                    columnField = "Brand";
                    break;

                case "Description of Bike":
                    columnKey = "BikeDescription";
                    columnField = "BikeDescription";
                    break;

                case "Bike Launch Date":
                    columnKey = "LaunchDate";
                    columnField = "LaunchDate";
                    break;

                case "Price($)":
                    columnKey = "Price";
                    columnField = "Price";
                    break;

                case "Presented By":
                    columnKey = "Presenter";
                    columnField = "Presenter";
                    break;
            }
            return { key: columnKey, name: column, fieldName: columnField, minWidth: 100, maxWidth: 200, isResizable: true }
        });

        this.state = {
            ListItems: this.props.ListItems,
            ListColumns: this._columns,
            selectionDetails: this._getSelectionDetails(),
            openPanel: false,
            panelType: "",
            BrandValue: ""
        };

        this.dismissPanel = this.dismissPanel.bind(this);
        this.saveItem = this.saveItem.bind(this);
        this.updateItem = this.updateItem.bind(this);

        // this.modal = React.createRef();
        // this.price = React.createRef();
        // this.brand = React.createRef();
        // this.imgUrl = React.createRef();
        // this.desc = React.createRef();
    };

    public render(): JSX.Element {
        const { ListItems, selectionDetails } = this.state;
        let panelBody = null;
        let panelHeader = "";
        const dropdownStyles: Partial<IDropdownStyles> = {
            dropdown: { width: 300 },
        };
        const options: IDropdownOption[] = [
            { key: "Harley Davidson", text: "Harley Davidson" },
            { key: "Ducati", text: "Ducati" },
            { key: "BMW", text: "BMW" },
            { key: "Honda", text: "Honda" },
            { key: "Yamaha", text: "Yamaha" },
            { key: "Kawasaki", text: "Kawasaki" }
        ];

        if (this.state.panelType == "New") {
            panelHeader = "New";
            panelBody = <>
                <Stack tokens={tokens.sectionStack}>
                    <Stack tokens={tokens.headingStack}>
                        <TextField id="txtModal" onChange={this.onFormChange} label="Model" required />
                        <TextField id="txtImageUrl" onChange={this.onFormChange} label="Image URL" required />
                        <Dropdown id="txtBrand" onChange={this.onBrandChange} placeholder="Select an option" label="Brand" options={options} styles={dropdownStyles} required />
                        <TextField id="txtBikeDescription" onChange={this.onFormChange} label="Bike Description" multiline autoAdjustHeight required />
                        <TextField id="txtPrice" onChange={this.onFormChange} type="number" label="Price" styles={dropdownStyles} required />
                        <DatePicker
                            className={null}
                            label="Launch Date"
                            isRequired={false}
                            allowTextInput={true}
                            ariaLabel={""}
                            firstDayOfWeek={DayOfWeek.Sunday}
                            strings={DayPickerStrings}
                            value={new Date()}
                            //formatDate={this.onFormatDate}
                            onSelectDate={this.onChangeLaunchDate}
                        />
                        <PeoplePicker onPresenterSelect={this.onPresenterChange} currentPresenter={[]}></PeoplePicker>
                    </Stack>
                </Stack>
            </>
        }
        else if (this.state.panelType == "View") {
            console.log(this._selection.getSelection()[0]);
            var item = { ...this._selection.getSelection()[0] as IBike };
            const activityItem: Partial<IActivityItemProps & React.ClassAttributes<{}>>[] = [
                {
                    key: 1,
                    activityDescription: [
                        <span key={1} className={classNames.nameText}>
                            {item.Presenter.Title}
                        </span>,
                        <span key={2}> launched this bike on - {new Intl.DateTimeFormat("en-GB", {
                            year: "numeric",
                            month: "long",
                            day: "2-digit"
                        }).format(new Date(item.LaunchDate))}
                        </span>,
                    ],
                    activityPersonas: [{ imageInitials: item.Presenter.Title.split(' ')[0].slice(0, 1) + item.Presenter.Title.split(' ')[1].slice(0, 1) }],
                    isCompact: true,
                }
            ];
            panelHeader = "View - " + item.Title;

            panelBody = <>
                <Image
                    src={item.ImageUrl}
                    imageFit={ImageFit.contain}
                    alt='Image'
                    width={200}
                    height={200}
                />
                <Label>{item.Brand}</Label>
                <label>Price - ${item.Price}</label>
                <Separator />
                <Stack tokens={tokens.sectionStack}>
                    <Stack tokens={tokens.headingStack}>
                        <Text variant={'large'} block>
                            {item.Title}
                        </Text>
                        <Text>
                            {item.BikeDescription}
                        </Text>
                    </Stack>
                </Stack>
                <Separator />
                <ActivityItem {...(activityItem[0] as IActivityItemProps)} key={activityItem[0].key} className={classNames.exampleRoot} />
            </>;
        }
        else if (this.state.panelType == "Update") {
            var item = { ...this._selection.getSelection()[0] as IBike };
            panelHeader = "Update - " + item.Title;

            this.formObj.ID = item.ID;
            this.formObj.Title = item.Title;
            this.formObj.Brand = this.state.BrandValue == "" ? item.Brand : this.state.BrandValue;
            this.formObj.ImageUrl = item.ImageUrl;
            this.formObj.BikeDescription = item.BikeDescription;
            this.formObj.LaunchDate = item.LaunchDate;
            this.formObj.Price = item.Price;
            this.formObj.Presenter = item.Presenter;

            let userPersona: IPersonaSharedProps = {
                imageUrl: "",
                imageInitials: 'BG',
                text: item.Presenter.Title,
                secondaryText: item.Presenter.EMail,
                tertiaryText: '',
                optionalText: '',
                id: item.Presenter.Id.toString(),
            };

            panelBody = <>
                <Stack tokens={tokens.sectionStack}>
                    <Stack tokens={tokens.headingStack}>
                        <TextField id="txtModal" onChange={this.onFormChange} value={item.Title} label="Model" required />
                        <TextField id="txtImageUrl" onChange={this.onFormChange} value={item.ImageUrl} label="Image URL" required />
                        <Dropdown id="txtBrand" onChange={this.onBrandChange} selectedKey={this.state.BrandValue == "" ? item.Brand : this.state.BrandValue} placeholder="Select an option" label="Brand" options={options} styles={dropdownStyles} required />
                        <TextField id="txtBikeDescription" onChange={this.onFormChange} value={item.BikeDescription} label="Bike Description" multiline autoAdjustHeight required />
                        <TextField id="txtPrice" onChange={this.onFormChange} value={item.Price.toString()} type="number" label="Price" styles={dropdownStyles} required />
                        <DatePicker
                            className={null}
                            label="Launch Date"
                            isRequired={false}
                            allowTextInput={true}
                            ariaLabel={""}
                            firstDayOfWeek={DayOfWeek.Sunday}
                            strings={DayPickerStrings}
                            value={new Date(this.formObj.LaunchDate)}
                            //formatDate={this.onFormatDate}
                            onSelectDate={this.onChangeLaunchDate}
                        />
                        <PeoplePicker onPresenterSelect={this.onPresenterChange} currentPresenter={[userPersona]}></PeoplePicker>
                    </Stack>
                </Stack>
            </>
        }

        return (
            <>
                <CommandBar items={this._items} />

                <Fabric>
                    <div className={exampleChildClass}>{selectionDetails}</div>
                    <Announced message={selectionDetails} />
                    <MarqueeSelection selection={this._selection}>
                        <DetailsList
                            items={this.state.ListItems}
                            columns={this.state.ListColumns}
                            setKey="set"
                            onRenderItemColumn={this._renderItemColumn}
                            layoutMode={DetailsListLayoutMode.justified}
                            selection={this._selection}
                            selectionPreservedOnEmptyClick={true}
                            ariaLabelForSelectionColumn="Toggle selection"
                            ariaLabelForSelectAllCheckbox="Toggle selection for all items"
                            checkButtonAriaLabel="Row checkbox"
                        />
                    </MarqueeSelection>
                </Fabric>

                <Panel
                    isOpen={this.state.openPanel}
                    onDismiss={this.dismissPanel}
                    headerText={panelHeader}
                    closeButtonAriaLabel="Close"
                    type={PanelType.medium}
                    onRenderFooterContent={() => this.onRenderFooterContent()}
                >
                    {panelBody}
                </Panel>
            </>
        );
    };

    private _renderItemColumn(item: IBike, index: number, column: IColumn) {
        let fieldContent: any = '';
        if (column.fieldName != "Presenter") {
            fieldContent = item[column.fieldName as keyof IBike] as string;
        } else {
            fieldContent = item["Presenter"]["Title"];
        }

        switch (column.key) {
            case 'Price':
                return <span>$ {fieldContent}</span>;

            case 'LaunchDate':
                return (<span>{
                    new Intl.DateTimeFormat("en-GB", {
                        year: "numeric",
                        month: "long",
                        day: "2-digit"
                    }).format(new Date(fieldContent))}
                </span>);

            case 'Presenter':
                return (
                    <span>
                        {fieldContent}
                    </span>
                );

            case 'BikeDescription':
                return (
                    <div className={textAreaClass}>
                        {fieldContent}
                    </div>
                );

            default:
                return <span>{fieldContent}</span>;
        }
    };

    private _getSelectionDetails(): string {
        const selectionCount = this._selection.getSelectedCount();
        this._items[0].disabled = true;
        this._items[1].disabled = true;
        this._items[2].disabled = true;
        this._items[3].disabled = true;

        switch (selectionCount) {
            case 0:
                this._items[0].disabled = false;
                return 'No items selected';
            case 1:
                this._items[0].disabled = true;
                this._items[1].disabled = false;
                this._items[2].disabled = false;
                this._items[3].disabled = false;
                return '1 item selected: ' + (this._selection.getSelection()[0] as IBike).Title;
            default:
                this._items[3].disabled = false;
                return `${selectionCount} items selected`;
        }
    };

    private dismissPanel() {
        this.setState({ openPanel: false, panelType: "" });
    };

    private saveItem() {
        console.log(this.formObj);
        const itemObj = {
            Title: this.formObj.Title,
            Price: this.formObj.Price,
            BikeDescription: this.formObj.BikeDescription,
            ImageUrl: this.formObj.ImageUrl,
            Brand: this.formObj.Brand,
            LaunchDate: new Date(this.formObj.LaunchDate),
            PresenterId: this.formObj.Presenter != null && typeof this.formObj.Presenter != "undefined" ? (this.formObj.Presenter.Id != null && typeof this.formObj.Presenter.Id != "undefined" ? this.formObj.Presenter.Id : 8) : 8
        }
        pnp.addItem(this.props.ListName, itemObj).then((response: IBike[]) => {           
            this.updateComponents();
            this.dismissPanel();
            this.formObj = {
                Title: "",
                Price: 0,
                Brand: "",
                ImageUrl: "",
                BikeDescription: "",
                ID: 0,
                LaunchDate: "",
                Presenter: null
            }
        }).catch(error => {
            console.log("Error Occured in adding record");
        });
    };

    private updateItem() {
        console.log(this.formObj);
        let selectedItem = this._selection.getSelection()[0] as IBike;
        const itemObj = {
            Title: this.formObj.Title,
            Price: this.formObj.Price,
            BikeDescription: this.formObj.BikeDescription,
            ImageUrl: this.formObj.ImageUrl,
            Brand: this.formObj.Brand,
            LaunchDate: new Date(this.formObj.LaunchDate),
        }
        pnp.updateItemById(this.props.ListName, selectedItem.ID, itemObj).then((response: IBike[]) => {
            this.updateComponents();
                this.dismissPanel();
                this.formObj = {
                    Title: "",
                    Price: 0,
                    Brand: "",
                    ImageUrl: "",
                    BikeDescription: "",
                    ID: 0,
                    LaunchDate: "",
                    Presenter: null
                }
        }).catch(error => {
            console.log("Error Occured in adding record");
        });
    };

    private onRenderFooterContent() {
        let cancelBtn = <DefaultButton onClick={this.dismissPanel}>Cancel</DefaultButton>;
        let saveBtn = <PrimaryButton onClick={this.saveItem} styles={buttonStyles}> Save </PrimaryButton>;
        if (this.state.panelType == "View") {
            saveBtn = null;
        }
        if (this.state.panelType == "Update") {
            saveBtn = <PrimaryButton onClick={this.updateItem} styles={buttonStyles}> Update </PrimaryButton>;
        }
        return <div>
            {saveBtn}
            {cancelBtn}
        </div>
    };

    private onNewClick = () => {
        this.setState({
            openPanel: true,
            panelType: "New"
        });
    };

    private onViewClick = () => {
        this.setState({
            openPanel: true,
            panelType: "View"
        });
    };

    private onUpdateClick = () => {
        this.setState({
            openPanel: true,
            panelType: "Update"
        });
    };

    private onDeleteClick = () => {
        if (this._selection.getSelection().length > 1) {
            let allSelectedItems = this._selection.getSelection() as IBike[];
            let allSelectedItemsID : number[] = [];
            allSelectedItems.map((item)=>{
                allSelectedItemsID.push(item.ID);
            });
            pnp.deleteItemsInBatch(this.props.ListName,allSelectedItemsID).then(
                (response:IBike[]) => {
                    console.log("Items deleted sucessfully");
                    this.updateComponents();
            }).catch(error => {
                console.log("Error in deleting batch Items");
            });
        }
        else if (this._selection.getSelection().length == 1) {
            let selectedItem = this._selection.getSelection()[0] as IBike;
            pnp.deleteItem(this.props.ListName, selectedItem.ID).then((response: IBike[]) => {               
                console.log("Item deleted sucessfully");
                this.updateComponents();
            }).catch(error => {
                console.log("Error Occured in deleting record");
            });
        }
    };

    private updateComponents = () => {
        pnp.getAllItems(this.props.ListName, "ID,Title,ImageUrl,Brand,BikeDescription,Price,LaunchDate,Presenter/Title,Presenter/Id,Presenter/EMail", "Presenter").then((response: IBike[]) => {
            this.setState({
                ListItems: response,
            });            
            this.props.onItemsChange(this.state.ListItems);
        });
    };
}
