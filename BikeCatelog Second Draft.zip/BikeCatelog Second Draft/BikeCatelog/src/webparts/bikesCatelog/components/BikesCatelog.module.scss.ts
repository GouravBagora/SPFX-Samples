/* tslint:disable */
require("./BikesCatelog.module.css");
const styles = {
  bikesCatelog: 'bikesCatelog_42b997e2',
  container: 'container_42b997e2',
  row: 'row_42b997e2',
  column: 'column_42b997e2',
  'ms-Grid': 'ms-Grid_42b997e2',
  title: 'title_42b997e2',
  subTitle: 'subTitle_42b997e2',
  description: 'description_42b997e2',
  button: 'button_42b997e2',
  label: 'label_42b997e2'
};

export default styles;
/* tslint:enable */