declare interface IEmployeeDirectory10WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'EmployeeDirectory10WebPartStrings' {
  const strings: IEmployeeDirectory10WebPartStrings;
  export = strings;
}
