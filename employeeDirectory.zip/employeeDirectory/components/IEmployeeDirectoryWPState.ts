import {IEmployees,IEmployee} from './IEmployees';

export interface IEmployeeDirectoryWPState{
    Message:string;
    tableColumns: any[];
    items: IEmployee[];
}