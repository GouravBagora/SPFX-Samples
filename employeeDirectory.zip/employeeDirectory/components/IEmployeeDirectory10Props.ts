import {sp, SPRest} from '@pnp/sp';
import { IWeb } from "@pnp/sp/webs";
import { SPHttpClient } from "@microsoft/sp-http";

export interface IEmployeeDirectory10Props {
  listName: string;
  currentEnvironment?: string;
  pnpweb?: SPRest;
  siteUrl?: string;
  spHTTPClient?: SPHttpClient;
}
