/* tslint:disable */
require("./EmployeeDirectory10.module.css");
const styles = {
  employeeDirectory10: 'employeeDirectory10_354f3dcb',
  container: 'container_354f3dcb',
  row: 'row_354f3dcb',
  column: 'column_354f3dcb',
  'ms-Grid': 'ms-Grid_354f3dcb',
  title: 'title_354f3dcb',
  subTitle: 'subTitle_354f3dcb',
  description: 'description_354f3dcb',
  button: 'button_354f3dcb',
  label: 'label_354f3dcb'
};

export default styles;
/* tslint:enable */