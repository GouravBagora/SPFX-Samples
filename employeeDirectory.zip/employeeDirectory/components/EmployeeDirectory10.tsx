import * as React from 'react';
import styles from './EmployeeDirectory10.module.scss';
import { IEmployeeDirectory10Props } from './IEmployeeDirectory10Props';
import { escape } from '@microsoft/sp-lodash-subset';
import {IEmployeeDirectoryWPState} from './IEmployeeDirectoryWPState';
import { IEmployeeDirectory10WebPartProps } from '../EmployeeDirectory10WebPart';
import DataTable, { createTheme } from 'react-data-table-component';
import MockHttpClient from '../MockHttpClient';
import {IEmployee, IEmployees} from './IEmployees';
import { sp } from '@pnp/sp/presets/all';


createTheme('solarized', {
  text: {
    primary: '#268bd2',
    secondary: '#2aa198',
  },
  background: {
    default: '#002b36',
  },
  context: {
    background: '#cb4b16',
    text: '#FFFFFF',
  },
  divider: {
    default: '#073642',
  },
  action: {
    button: 'rgba(0,0,0,.54)',
    hover: 'rgba(0,0,0,.08)',
    disabled: 'rgba(0,0,0,.12)',
  },
});

export default class EmployeeDirectory10 extends React.Component<IEmployeeDirectory10Props, IEmployeeDirectoryWPState> {
  constructor(props:IEmployeeDirectory10WebPartProps, state:IEmployeeDirectoryWPState){
    super(props);
    this.state={
      Message:"Lets see how it works",
      tableColumns:[],
      items:[]
    };
  }

  protected getRecords = () => {
    if(this.props.currentEnvironment == "SharePoint"){
      sp.web.lists.getByTitle(this.props.listName)  
      .items.orderBy('Id', false).top(5000).select('Title,Address,Department,Joining_Date').get().then((Items: IEmployee[]) => {  
        if(Items.length > 0){
          const columns = [
            {
              name: 'Full Name',
              selector: 'Title',
              sortable: true,
            },
            {
              name: 'Address',
              selector: 'Address',
              sortable: false,
              center: true,
            },
            {
              name: 'Department',
              selector: 'Department',
              sortable: true,
              center: true,
            },
            {
              name: 'Joining_Date',
              selector: 'Joining_Date',
              sortable: true,
              center: true,
            }
          ]/*Object.keys(Items[0]).map((key, id)=>{
            return {
              name: key,
              selector: key
            }
          })*/
          this.setState({
            items : Items,
            Message: "Here are the list items.",
            tableColumns: columns
          });
        }
        else{
          this.setState({
            Message : "OOPS!! No records Found"
          });
        }
      }, (error: any): void => {  
        console.log(error);  
        this.setState({
          Message : "OOPS!! No records Found"
        });
      });
    }
    else if(this.props.currentEnvironment == "Local"){
      MockHttpClient.get().then((Items: IEmployee[])=>{        
        if(Items.length > 0){
          const columns = Object.keys(Items[0]).map((key, id)=>{
            return {
              name: key,
              selector: key
            }
          })
          this.setState({
            items : Items,
            Message: "Here are the list items.",
            tableColumns: columns
          });
        }
        else{
          this.setState({
            Message : "OOPS!! No records Found"
          });
        }
      });
    }
  }

  protected hideRecords = () => {
    this.setState({
      Message : "Records are hidden.Click get records to show again."
    });
  }

  public render(): React.ReactElement<IEmployeeDirectory10Props> {
    let dataTable;
    if(this.state.Message == "Here are the list items."){
      dataTable = 
      <div className={ styles.container }>
          <div className={ styles.row }>
              <DataTable
                    title="Employee Directory"
                    columns={this.state.tableColumns}
                    data={this.state.items}
                    theme="solarized"
              />
          </div>
      </div>;
    }
    return (
      <div className={ styles.employeeDirectory10 }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>              
              <p className={ styles.description }><label className={ styles.label}>List Name:</label>{escape(this.props.listName)}</p>
              <p className={ styles.description }><label className={ styles.label}>{this.state.Message}</label></p>
              <button className={styles.button} title="Click to get Records" onClick={() => this.getRecords()}>Get Records</button>&nbsp;&nbsp;&nbsp;              
              <button className={styles.button} title="Click to hide Records" onClick={() => this.hideRecords()}>Hide Records</button>
            </div>
          </div>          
        </div>
          {dataTable}
      </div>
    );
  }
}
