import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import { SPHttpClient } from "@microsoft/sp-http";
import {sp, SPRest} from '@pnp/sp';
import {Environment,EnvironmentType} from '@microsoft/sp-core-library';

import * as strings from 'EmployeeDirectory10WebPartStrings';
import EmployeeDirectory10 from './components/EmployeeDirectory10';
import { IEmployeeDirectory10Props } from './components/IEmployeeDirectory10Props';
//import { IWeb } from '@pnp/sp/webs';
//import { PnPClientStorage } from '@pnp/common';

export interface IEmployeeDirectory10WebPartProps {
  listName: string;
  currentEnvironment?: string;
  pnpweb?: SPRest;
  siteUrl?: string;
  spHTTPClient?: SPHttpClient;
}

export default class EmployeeDirectory10WebPart extends BaseClientSideWebPart <IEmployeeDirectory10WebPartProps> {
  currentEnvironment = (Environment.type === EnvironmentType.Local) ? "Local" : ((Environment.type == EnvironmentType.SharePoint || Environment.type == EnvironmentType.ClassicSharePoint) ? "SharePoint" : "Test");
  
  public onInit(): Promise<void> {  
    return super.onInit().then(_ => {  
      sp.setup({  
        spfxContext: this.context  
      });  
    });  
  }

  public render(): void {    
    const element: React.ReactElement<IEmployeeDirectory10Props> = React.createElement(
      EmployeeDirectory10,
      {
        listName:this.properties.listName,
        currentEnvironment: this.currentEnvironment//,
        //siteUrl: this.context.pageContext.web.absoluteUrl,
        //pnpweb:
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: strings.ListNameFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
