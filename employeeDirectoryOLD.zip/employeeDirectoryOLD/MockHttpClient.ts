import {IEmployee} from './IEmployeeList';

export default class MockHttpClient {
    private static items: IEmployee[] = [
        {Title: 'Gourav Bagora',Address: '50, Airport Road, Indore',Department: 'SharePoint Development', Joining_Date:new Date('10/7/2019')},
        {Title: 'Vivek Singh',Address: '32, MG Nagar, Faridabad',Department: 'SharePoint Development', Joining_Date:new Date('01/17/2009')},
        {Title: 'Sagar Kausik',Address: '1, Royal Street, Dehradun',Department: 'UI/UX', Joining_Date:new Date('11/27/2018')},
        {Title: 'Parcheta Desai',Address: '47, AK Towers, Gaziabad',Department: 'UI/UX', Joining_Date:new Date('10/7/2019')},
        {Title: 'Tarun Arora',Address: '34, Dwarka, Delhi',Department: 'SharePoint Development', Joining_Date:new Date('10/7/2019')},
        {Title: 'Nitin Goel',Address: '68A Silicon City, Sector 39, Gurugram',Department: 'SharePoint Development', Joining_Date:new Date('02/16/2016')},
        {Title: 'Ajay Sharma',Address: '50, Airport Road, Indore',Department: 'SharePoint Development', Joining_Date:new Date('03/3/2017')},
        {Title: 'M. Shamim',Address: '4B JMD Towers, Sector 45, Gurugram',Department: 'Admin', Joining_Date:new Date('05/6/2019')}
    ];

    public static get(): Promise<IEmployee[]>{
        return new Promise<IEmployee[]>((resolve) => {
            resolve(MockHttpClient.items);
        });
    }
}