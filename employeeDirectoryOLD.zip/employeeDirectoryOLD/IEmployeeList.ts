export interface IEmployees{
    value:IEmployee[];
}

export interface IEmployee{
    Title: string,
    Address: string,
    Department: string,
    Joining_Date: Date
}