export interface IEmployeeDirectoryProps {
  listName:string;
}
