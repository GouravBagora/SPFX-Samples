/* tslint:disable */
require("./Custom.module.css");
const styles = {
  list: 'list_9096e128',
  listItem: 'listItem_9096e128'
};

export default styles;
/* tslint:enable */