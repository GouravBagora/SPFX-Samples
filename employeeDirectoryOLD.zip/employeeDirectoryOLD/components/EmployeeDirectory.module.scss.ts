/* tslint:disable */
require("./EmployeeDirectory.module.css");
const styles = {
  employeeDirectory: 'employeeDirectory_0dbb82cf',
  container: 'container_0dbb82cf',
  row: 'row_0dbb82cf',
  column: 'column_0dbb82cf',
  'ms-Grid': 'ms-Grid_0dbb82cf',
  title: 'title_0dbb82cf',
  subTitle: 'subTitle_0dbb82cf',
  description: 'description_0dbb82cf',
  button: 'button_0dbb82cf',
  label: 'label_0dbb82cf',
  list: 'list_0dbb82cf',
  listItem: 'listItem_0dbb82cf'
};

export default styles;
/* tslint:enable */