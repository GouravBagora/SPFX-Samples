import * as React from 'react';
import styles from './EmployeeDirectory.module.scss';
import { IEmployeeDirectoryProps } from './IEmployeeDirectoryProps';
//import { IEmployees, IEmployee } from './IEmployeeDirectoryState';
import { IEmployees,IEmployee } from '../IEmployeeList';
import { escape } from '@microsoft/sp-lodash-subset';
import DataTable, { createTheme } from 'react-data-table-component';
import {Environment,EnvironmentType} from '@microsoft/sp-core-library';
import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';
import MockHttpClient from '../MockHttpClient';
import { sp } from "@pnp/sp/presets/all";

createTheme('solarized', {
  text: {
    primary: '#268bd2',
    secondary: '#2aa198',
  },
  background: {
    default: '#002b36',
  },
  context: {
    background: '#cb4b16',
    text: '#FFFFFF',
  },
  divider: {
    default: '#073642',
  },
  action: {
    button: 'rgba(0,0,0,.54)',
    hover: 'rgba(0,0,0,.08)',
    disabled: 'rgba(0,0,0,.12)',
  },
});

export default class EmployeeDirectory extends React.Component<IEmployeeDirectoryProps,{data: any[],columns:any[]}> {//{data: any[],columns:any[]}
  constructor(props){
    super(props);
    this.state={
      data: [],
      columns:[
        {
          name: 'Full Name',
          selector: 'Title',
          sortable: true,
        },
        {
          name: 'Address',
          selector: 'Address',
          sortable: false,
          center: true,
        },
        {
          name: 'Department',
          selector: 'Department',
          sortable: true,
          center: true,
        }
      ]
    };
  }  

  protected getListItems(): void {
    if (Environment.type === EnvironmentType.Local) {
      this._getMockListData().then((response) => {
        this.setState({
          data:response.value
        });
      });
    }
    else if (Environment.type == EnvironmentType.SharePoint ||
              Environment.type == EnvironmentType.ClassicSharePoint) {
      this._getListData()
        .then((response) => {
          this.setState({
            data:response.value
          });
        });
    }
  };
  
  protected _getListData(): Promise<IEmployees> {
    /*return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + `/_api/web/lists?$filter=Hidden eq false`, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });*/
      return sp.web.lists.getByTitle('EmployeesList')  
      .items.orderBy('Id', false).top(5000).select('*').get().then(Items => {  
        const reponse = {value : Items};
        return reponse;  
      }, (error: any): void => {  
        console.log(error);  
      });
  }
  
  protected _getMockListData(): Promise<IEmployees> {
    return MockHttpClient.get()
      .then((data: IEmployee[]) => {
        var listData: IEmployees = { value: data };
        return listData;
      }) as Promise<IEmployees>;
  }

  public render(): React.ReactElement<IEmployeeDirectoryProps> {
    return (
      <div className={styles.container}>        
        <button type="button" className={styles.button} onClick={()=>{this.getListItems()}}>Click</button>              
        <DataTable
          title="Employee Directory"
          columns={this.state.columns}
          data={this.state.data}
          theme="solarized"
        />
      </div>      
    );
  }
}
